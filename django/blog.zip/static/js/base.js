document.querySelector("#logout").addEventListener("click", () => document.querySelector("#logoutForm").submit());
